import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter,Link,Route,Routes,} from "react-router-dom";
import Home from './pages/Home/HomePage';
import About from './pages/About/Details';
import Price from './pages/Price/Whatsnew';
import Delivery from './pages/Delivery/Delivery'
import Footer from './componunts/Footer/Footer';
import Categories from './pages/Categories/Categories';
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/price" element={<Price />} />
        <Route path='delivery' element={<Delivery/>}/>
        <Route path='categories' element={<Categories/>}/>
      </Routes>
    </BrowserRouter>
  );
}
