// import Layout from "../../Layout/Layout";
// import Footer from "../../componunts/Footer/Footer";
// import './Whatsnew.css';
// import React, { useState } from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faHeart as farHeart } from '@fortawesome/free-regular-svg-icons';
// import { faHeart as fasHeart, faStar } from '@fortawesome/free-solid-svg-icons';
// const Price = ({ imageUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQok-h1Luj3jjT4woPMDmrXYSfF4dztUMoKNI906e-hKC6KoON_7JOoiicRaQ&s",
//      productName="", 
//     //  description="This is a brief description of the product.", 
//      price="8909",
//      initialRating ="3",
//     }) => {
//     const [isFavorite, setIsFavorite] = useState(false);
//     const [rating, setRating] = useState(initialRating || 0);
//     const toggleFavorite = () => {
//      setIsFavorite(!isFavorite);
//    };
//    const handleStarClick = (clickedIndex) => {
//      setRating(clickedIndex + 1);
//    };
//    const stars = Array(5).fill(0);
//    return(
//   <Layout>
//   <div>
//   <div className="homepage-cards">
//     <div className="card-container">
//     <div className="heart-icon" onClick={toggleFavorite}>
//     <FontAwesomeIcon icon={isFavorite ? fasHeart : farHeart} color={isFavorite ? 'red' : 'black'} />
//     </div>
//     <img src='https://w7.pngwing.com/pngs/164/804/png-transparent-e-commerce-online-shopping-icon-double-twelve-shopping-cart-material-love-heart-coffee-shop-thumbnail.png' alt={productName} className="card-image" />
//     <div className="card-info">
//     <h2 className="card-name">{productName}</h2>
//     <span className="card-price">{price}</span>
//     </div>

//     <div className="card-rating">
//     {stars.map((_, index) => (
//       <FontAwesomeIcon
//         key={index}
//         icon={faStar}
//         color={index < rating ? 'yellow' : 'grey'}
//         onClick={() => handleStarClick(index)}
//       />
//     ))}
//     </div>
//     <button className="add-to-cart-btn">Add to Cart</button>
//     </div>
//   </div>
//   <Footer />
// </div>
// </Layout>
//     )
// }
// export default Price;



import Layout from "../../Layout/Layout";
import Footer from "../../componunts/Footer/Footer";
import './Whatsnew.css';
import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart as farHeart } from '@fortawesome/free-regular-svg-icons';
import { faHeart as fasHeart, faStar } from '@fortawesome/free-solid-svg-icons';

const initialRatings = Array(10).fill(0);
const initialFavorites = Array(10).fill(false);
 
const Price = () => {
  const [ratings, setRatings] = useState(initialRatings);
  const [favorites, setFavorites] = useState(initialFavorites);
 
  const handleStarClick = (imageIndex, clickedIndex) => {
    const newRatings = [...ratings];
    newRatings[imageIndex] = clickedIndex + 1;
    setRatings(newRatings);
  };
 
  const toggleFavorite = (imageIndex) => {
    const newFavorites = [...favorites];
    newFavorites[imageIndex] = !newFavorites[imageIndex];
    setFavorites(newFavorites);
  };
 
  const images = Array.from({ length: 10 }, (_, index) => ({
    id: index + 1,
src: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6OCY6O9_QJqejnplx5_JmVuvZCc7RgevAOw&usqp=CAU',
    alt: `Product ${index + 1}`,
  }));
 
  return (
    <Layout>
      <div>
        <div className="homepage-cards">
          {images.map((image) => (
            <div key={image.id} className="card">
              <img src={image.src} alt={image.alt} className="card-image" />
              <div className='heart-icon' onClick={()=>toggleFavorite(image.id - 1)}>
              <FontAwesomeIcon icon={farHeart} color={favorites[image.id - 1] ? 'red' : 'white'} />
              </div>
 
              <div className="card-info">
              <h2 className='card-name'>Product {image.id}</h2>              
              <span className="card-price">$8909</span>
              </div>
 
              <div className="card-rating">
                {Array(5).fill(0).map((_, starIndex) => (
                  <FontAwesomeIcon
                    key={starIndex}
                    icon={farHeart}
                    color={starIndex < ratings[image.id - 1] ? 'yellow' : 'grey'}
                    onClick={() => handleStarClick(image.id - 1, starIndex)}
                  />
                ))}
              </div>
 
              <button className="add-to-cart-btn">Add to Cart</button>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};
export default Price;