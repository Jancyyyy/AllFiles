import Layout from "../../Layout/Layout";
function About(){
    return(
        <Layout>
        <div className="product-details">
        <h6>Details of the products can be found on this page.</h6>
        </div>
        </Layout>
    )
}
export default About;