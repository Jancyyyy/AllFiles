// import Layout from "../../Layout/Layout";
// function About(){
//     return(
//         <Layout>
//         <div className="product-details">
//         <h6>Details of the products can be found on this page.</h6>
//         </div>
//         </Layout>
//     )
// }
// export default About;
import React from "react";
import Layout from "../../Layout/Layout";
function Delivery(){
    return(
        <Layout>
        <div>
        <h6>This page will contain details of the products when they are delivered.</h6>
        </div>
        </Layout>
    )
}
export default Delivery