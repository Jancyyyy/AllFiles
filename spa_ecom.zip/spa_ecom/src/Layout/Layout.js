import Header from "../componunts/Header/Header";
import Footer from "../componunts/Footer/Footer";
import React from "react";
function Layout(props){
    return(
       <>
         <Header />
         {props.children}
        <Footer />
       </>
    )
}
export default Layout;