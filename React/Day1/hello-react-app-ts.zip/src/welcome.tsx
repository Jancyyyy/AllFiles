

const x = 5;
export default x;


export const welcome = (
    <h3>Result is 4*5!</h3>
)