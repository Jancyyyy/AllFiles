import React from 'react';
import Hello , {BruceImage} from './hello';
import x,{welcome} from './welcome';
import './App.css';

// functional component
function App() {
  return (
    <div className="App">          
      <h1>Welcome to React.js! - using create-react-app - typescript!</h1>
      <h2>Result is (x*4+11) :{x*4+11}!</h2>      
      {welcome}      
      <Hello />
      <BruceImage />
    </div>
  );
}

export default App;
